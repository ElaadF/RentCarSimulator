/**
 * BuyCarsServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package fr.upem.manage;

public interface BuyCarsServiceService extends javax.xml.rpc.Service {
    public java.lang.String getBuyCarsServiceAddress();

    public fr.upem.manage.BuyCarsService getBuyCarsService() throws javax.xml.rpc.ServiceException;

    public fr.upem.manage.BuyCarsService getBuyCarsService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
