package fr.upem.manage;


import java.rmi.Remote;

public interface IClient extends Remote {
	
}


