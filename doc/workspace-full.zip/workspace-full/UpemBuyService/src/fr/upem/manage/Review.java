package fr.upem.manage;


public class Review {
	private IClient client;
	private Long idVehicle;
	private short mark;
	private String comment;
	
	
	public Review(IClient client, Long idVehicle, short mark, String comment) {
		this.client = client;
		this.idVehicle = idVehicle;
		this.mark = mark;
		this.comment = comment;
	}
	
	public Review() {
	}
	
	public IClient getClient() {
		return client;
	}
	
	public Long getIdVehicle() {
		return idVehicle;
	}
	
	public short getMark() {
		return mark;
	}
	
	public String getComment() {
		return comment;
	}
	
}
