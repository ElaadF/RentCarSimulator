package fr.upem.manage;

import java.math.BigDecimal;
import java.math.MathContext;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.tempuri.ConverterLocator;
import org.tempuri.ConverterSoap;

import fr.bank.account.Account;
import fr.bank.account.AccountServiceLocator;
import fr.bank.account.AccountSoapBindingStub;

public class BuyCarsService {
	public HashMap<Long, List<Vehicle>> carts = new HashMap<>();
	public IVehicleDeposit deposit;
	public double price;
	
	public BuyCarsService() {
	}

	public void removeFromCart(long idClient, long idVehicle) {	
		List<Vehicle> newVehicles = carts.get(idClient);
		for (Vehicle vehicle : newVehicles) {
			if(vehicle.getId() == idVehicle)
				newVehicles.remove(vehicle);
		}
		carts.replace(idClient, newVehicles);

	}

	


	public double getPriceByCurrency(String currency) {
		ConverterSoap converter;
		try {
			converter = new ConverterLocator().getConverterSoap();
			BigDecimal newTotalPrice = converter.getConversionAmount("EUR", currency, converter.getLastUpdateDate(), new BigDecimal(price, MathContext.DECIMAL64));
			return newTotalPrice.doubleValue();
		} catch (ServiceException | RemoteException e) {
			e.printStackTrace();
		}
		return -1;

	}

	public boolean buy(long idClient, String currency) throws ServiceException, RemoteException, MalformedURLException, NotBoundException {
		Account service = new AccountServiceLocator().getAccount();
		((AccountSoapBindingStub)service).setMaintainSession(true);
		System.out.println("BuyCars - fonction buy : " + carts);
		List<Vehicle> Vehicles = carts.get(idClient);
		deposit = (IVehicleDeposit) Naming.lookup("vehicleDeposit");


		if(service.withdrawal(idClient, price)) {
			for (Vehicle vehicle : Vehicles) {
				deposit.removeVehicle(vehicle.getId());				
			}
			return true;
		}

		return false;
	}
	
	public  Vehicle[] showVehicles() throws RemoteException, MalformedURLException, NotBoundException {
		return deposit.getVehicles();
	}

	public  Vehicle[] showByModels(String model) throws RemoteException, MalformedURLException, NotBoundException {
		return deposit.searchByModel(model);
	}

	public  Review[] showReviewsById(long idVehicle) throws RemoteException, MalformedURLException, NotBoundException {
		return deposit.getReviewsById(idVehicle);
	}
	
	public  Vehicle[] showByBrand(String brand) throws RemoteException, MalformedURLException, NotBoundException {
		return deposit.searchByModel(brand);
	}

	public boolean addToCart(long idVehicle, long idClient) throws MalformedURLException, RemoteException, NotBoundException {
		deposit = (IVehicleDeposit) Naming.lookup("vehicleDeposit");
		if (deposit.isBuyable(idVehicle)){
			List<Vehicle> a = carts.putIfAbsent(idClient, new ArrayList<>());
			carts.get(idClient).add(deposit.getVehicleById(idVehicle));
			price = price + deposit.getVehicleById(idVehicle).getBuyPrice();
			System.out.println("BuyCars - fonction add : " + carts);
			if(a==null)
				return false;
			return true;
		}
		return false;
	}

}
